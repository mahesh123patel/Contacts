﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MAMAJI_APP.Class
{
    public class Complaint
    {
        public decimal ComplaintID { get; set; }
        public string ComplaintName { get; set; }
        public decimal? DistrictID { get; set; }
        public string DistrictHindiName { get; set; }
        public decimal? BlockID { get; set; }
        public string BlockHindiName { get; set; }
        public string ComplaintAddress { get; set; }
        public decimal? ConTypeID { get; set; }
        public string ConType { get; set; }
        public string MobileNo { get; set; }
        public string Description { get; set; }
        public decimal? CreatedBY { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Status { get; set; }
        public decimal? AssignOfficerID { get; set; }
        public string ISBlocked { get; set; }
        public string OfficerName { get; set; }
        
       
       
        
    }

    public class ComplaintManager
    {
        private string connectionString;

        public ComplaintManager(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public string InsertComplaint(Complaint complaint)
        {
            return ExecuteScalar("INSERT", complaint);
        }

        public void UpdateComplaint(Complaint complaint)
        {
            ExecuteNonQuery("UPDATE", complaint);
        }

        public void DeleteComplaint(decimal complaintID)
        {
            ExecuteNonQuery("DELETE", new Complaint { ComplaintID = complaintID });
        }

        public List<Complaint> GetComplaints(decimal? complaintID = null)
        {
            return ExecuteQuery("SELECT", complaintID);
        }

        private void ExecuteNonQuery(string action, Complaint complaint)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ManageComplaint", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", action);
                    cmd.Parameters.AddWithValue("@ComplaintID", complaint.ComplaintID != 0 ? (object)complaint.ComplaintID : DBNull.Value);
                    cmd.Parameters.AddWithValue("@ComplaintName", complaint.ComplaintName ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@DistrictID", complaint.DistrictID.HasValue ? (object)complaint.DistrictID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@BlockID", complaint.BlockID.HasValue ? (object)complaint.BlockID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@ComplaintAddress", complaint.ComplaintAddress ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@ConTypeID", complaint.ConTypeID.HasValue ? (object)complaint.ConTypeID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@MobileNo", complaint.MobileNo ?? (object)DBNull.Value);
                    
                    cmd.Parameters.AddWithValue("@Description", complaint.Description ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@CreatedBY", complaint.CreatedBY.HasValue ? (object)complaint.CreatedBY.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@Status", complaint.Status ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@AssignOfficerID", complaint.AssignOfficerID.HasValue ? (object)complaint.AssignOfficerID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@ISBlocked", complaint.ISBlocked ?? (object)DBNull.Value);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private List<Complaint> ExecuteQuery(string action, decimal? complaintID)
        {
            List<Complaint> complaints = new List<Complaint>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ManageComplaint", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", action);
                    cmd.Parameters.AddWithValue("@ComplaintID", complaintID.HasValue ? (object)complaintID.Value : DBNull.Value);

                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Complaint complaint = new Complaint
                            {
                                ComplaintID = reader.GetDecimal(reader.GetOrdinal("ComplaintID")),
                                ComplaintName = reader.GetString(reader.GetOrdinal("ComplaintName")),
                                DistrictID = reader.IsDBNull(reader.GetOrdinal("DistrictID")) ? (decimal?)null : reader.GetDecimal(reader.GetOrdinal("DistrictID")),
                                BlockID = reader.IsDBNull(reader.GetOrdinal("BlockID")) ? (decimal?)null : reader.GetDecimal(reader.GetOrdinal("BlockID")),
                                ComplaintAddress = reader.GetString(reader.GetOrdinal("ComplaintAddress")),
                                ConTypeID = reader.IsDBNull(reader.GetOrdinal("ConTypeID")) ? (decimal?)null : reader.GetDecimal(reader.GetOrdinal("ConTypeID")),
                                MobileNo = reader.GetString(reader.GetOrdinal("MobileNo")),
                                //ConSubTypeID = reader.IsDBNull(reader.GetOrdinal("ConSubTypeID")) ? (decimal?)null : reader.GetDecimal(reader.GetOrdinal("ConSubTypeID")),
                                Description = reader.GetString(reader.GetOrdinal("Description")),
                                CreatedBY = reader.IsDBNull(reader.GetOrdinal("CreatedBY")) ? (decimal?)null : reader.GetDecimal(reader.GetOrdinal("CreatedBY")),
                                CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                                Status = reader.GetString(reader.GetOrdinal("Status")),
                                AssignOfficerID = reader.IsDBNull(reader.GetOrdinal("AssignOfficerID")) ? (decimal?)null : reader.GetDecimal(reader.GetOrdinal("AssignOfficerID")),
                                ISBlocked = reader.GetString(reader.GetOrdinal("ISBlocked")),
                                DistrictHindiName = reader.GetString(reader.GetOrdinal("DistrictHindiName")),
                                BlockHindiName = reader.GetString(reader.GetOrdinal("BlockHindiName")),
                                ConType = reader.GetString(reader.GetOrdinal("ConType")),
                                OfficerName = reader.GetString(reader.GetOrdinal("OfficerName")),
                            };

                            complaints.Add(complaint);
                        }
                    }
                }
            }

            return complaints;
        }

        private string ExecuteScalar(string action, Complaint complaint)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ManageComplaint", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", action);
                    cmd.Parameters.AddWithValue("@ComplaintID", complaint.ComplaintID != 0 ? (object)complaint.ComplaintID : DBNull.Value);
                    cmd.Parameters.AddWithValue("@ComplaintName", complaint.ComplaintName ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@DistrictID", complaint.DistrictID.HasValue ? (object)complaint.DistrictID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@BlockID", complaint.BlockID.HasValue ? (object)complaint.BlockID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@ComplaintAddress", complaint.ComplaintAddress ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@ConTypeID", complaint.ConTypeID.HasValue ? (object)complaint.ConTypeID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@MobileNo", complaint.MobileNo ?? (object)DBNull.Value);

                    cmd.Parameters.AddWithValue("@Description", complaint.Description ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@CreatedBY", complaint.CreatedBY.HasValue ? (object)complaint.CreatedBY.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@Status", complaint.Status ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@AssignOfficerID", complaint.AssignOfficerID.HasValue ? (object)complaint.AssignOfficerID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@ISBlocked", complaint.ISBlocked ?? (object)DBNull.Value);

                    conn.Open();
                    return cmd.ExecuteScalar().ToString();
                }
            }
        }
    }
}