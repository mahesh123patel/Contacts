﻿using MAMAJI_APP.Class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MAMAJI_APP.ComplaintPage
{
    public partial class ComplaintRegistration1 : System.Web.UI.Page
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["conn"].ToString(); // Replace with your actual connection string
        private ComplaintManager complaintManager;
        protected void Page_Load(object sender, EventArgs e)
        {
            complaintManager = new ComplaintManager(connectionString);
            if(!IsPostBack)
            {
                FillDistrict(ddlCompDistrict);
                FillBlock(ddlBlock);
                FillOfficer(ddlOfficer);
                FillConType(ddlConType);
            }
        }

        protected void ComplaintSubmit_Click(object sender, EventArgs e)
        {
            Complaint complaint = new Complaint
            {
                ComplaintName = txtComplaintName.Text.Trim(),
                DistrictID = Convert.ToInt16(ddlCompDistrict.SelectedItem.Value),
                BlockID = Convert.ToInt16(ddlBlock.SelectedItem.Value),
                ComplaintAddress = txtComplaintAddress.Text.Trim(),
                ConTypeID = Convert.ToInt16(ddlConType.SelectedItem.Value),
                MobileNo = txtMobileNo.Text.Trim(),
                Description = txtDescription.Text.Trim(),
                CreatedBY = 1,
                Status = "WIP",
                AssignOfficerID = Convert.ToInt16(ddlCompDistrict.SelectedItem.Value),
                ISBlocked = "A"
            };

           string compid = complaintManager.InsertComplaint(complaint);
           CommonClass cls = new CommonClass();
           string s = Convert.ToBase64String(cls.Encrypt(compid));
            Response.Redirect("../ComplaintPage/DisplayComplaintDetails.aspx?C="+HttpUtility.UrlEncode(s));
        }
        private void FillConType(DropDownList ddlConType)
        {
            List<ConType> contyps = new List<ConType>();
            ConTypeManager _conTypeManager = new ConTypeManager(connectionString);
            contyps = _conTypeManager.GetConTypes();
            ddlConType.DataSource = contyps;
            ddlConType.DataTextField = "ConTypeName";
            ddlConType.DataValueField = "ConTypeID";
            ddlConType.DataBind();
        }
        private void FillDistrict(DropDownList ddlDistrict)
        {
            List<District> dist = new List<District>();
            DistrictManager _districtManager = new DistrictManager(connectionString);
            dist = _districtManager.GetDistricts();
            ddlDistrict.DataSource = dist;
            ddlDistrict.DataTextField = "DistrictName";
            ddlDistrict.DataValueField = "DistrictID";
            ddlDistrict.DataBind();
        }
        private void FillOfficer(DropDownList ddlOfficer)
        {
            List<Officer> _officers = new List<Officer>();
            OfficerManager _officerManager = new OfficerManager(connectionString);
            _officers = _officerManager.GetOfficers();
            ddlOfficer.DataSource = _officers;
            ddlOfficer.DataTextField = "OfficerName";
            ddlOfficer.DataValueField = "OfficerID";
            ddlOfficer.DataBind();
        }
        private void FillBlock(DropDownList ddlBlock)
        {
            List<Block> _blocks = new List<Block>();
            BlockManager _blockManager = new BlockManager(connectionString);
            _blocks = _blockManager.GetBlocks();
            ddlBlock.DataSource = _blocks;
            ddlBlock.DataTextField = "BlockName";
            ddlBlock.DataValueField = "BlockID";
            ddlBlock.DataBind();
        }
    }
}